/sbin/ledcfg -f /var/tmp/mycfg/led.conf
