/sbin/ledcfg -f /var/tmp/mycfg/led.conf
ifconfig eth0 down
ifconfig eth0 up
