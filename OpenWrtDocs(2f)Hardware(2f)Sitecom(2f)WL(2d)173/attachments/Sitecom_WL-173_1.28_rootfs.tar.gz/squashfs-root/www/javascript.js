//----------------------------------------------------------------------------------
//                           Disciption
//      This is a JavaScript Document for multiple languages webs.
//      Just to build or modify the cookie when language selected. And show
//  the right text in the selected language!
//      This application must be used with multiple languages doucument
//  which in defined type. 


//----------------------------------------------------------------------------------
//      Define some variables for selecting language. Application select text
//  in right language just by the value of the variable "stype"!

//----------------------------------------------------------------------------------
//      Set cookie and Set language which selected.

function setlanguage()
{
  var vervaldatum = new Date()
      vervaldatum.setDate(vervaldatum.getDate()+365);
  var newValue = document.form.site.options[document.form.site.selectedIndex].value;
  	document.cookie="language="+newValue+"; expires="+vervaldatum+"; path=/";
      parent.window.location.href = "../index.html";	//reload();	//
}

function getCookie(c_name)
{
  if (document.cookie.length>0)
  {
    c_start=document.cookie.indexOf(c_name + "=")
    if (c_start!=-1)
    {
      c_start=c_start + c_name.length+1;
      c_end=document.cookie.indexOf(";",c_start);
      if (c_end==-1) c_end=document.cookie.length;
      return unescape(document.cookie.substring(c_start,c_end));
    }
  }
  return 0;
}


//----------------------------------------------------------------------------------
//     Show the text in right language.

var stype = getCookie('language');


function showText(text)
{
  return text[stype];
}

//----------------------------------------------------------------------------------
//      end of file  --------------------
