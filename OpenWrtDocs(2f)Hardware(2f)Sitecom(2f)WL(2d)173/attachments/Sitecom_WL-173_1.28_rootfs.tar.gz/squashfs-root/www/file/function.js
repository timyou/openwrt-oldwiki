//******************************************************************************************
function validateKey(str)
{
   for (var i=0; i<str.length; i++) {
    if ( (str.charAt(i) >= '0' && str.charAt(i) <= '9') ||
    		(str.charAt(i) == '.' ) )
			continue;
	return 0;
  }
  return 1;
}

function getDigit(str, num)
{
  i=1;
  if ( num != 1 ) {
  	while (i!=num && str.length!=0) {
		if ( str.charAt(0) == '.' ) {
			i++;
		}
		str = str.substring(1);
  	}
  	if ( i!=num )
  		return -1;
  }
  for (i=0; i<str.length; i++) {
  	if ( str.charAt(i) == '.' ) {
		str = str.substring(0, i);
		break;
	}
  }
  if ( str.length == 0)
  	return -1;
  d = parseInt(str, 10);
  return d;
}

function checkDigitRange(str, num, min, max)
{
  d = getDigit(str,num);
  
  if ( d > max || d < min )
      	return false;
  return true;
}

function checkMask(str, num, msg)
{
  	d = getDigit(str,num);
  	
	if( !(d==0 || d==128 || d==192 || d==224 || d==240 || d==248 || d==252 || d==254 || d==255 )) {
		alert(msg + showText(slan34));
		return false;
	}
		return true;
}

function checkIpAddr(field, msg)
{
   if ( validateKey(field) == 0) {
      alert(msg + showText(slan35));
      return false;
   }
   if ( !checkDigitRange(field,1,0,255) ) {
      alert(msg + showText(slan36));
      return false;
   }
   if ( !checkDigitRange(field,2,0,255) ) {
      alert(msg + showText(slan37));
      return false;
   }
   if ( !checkDigitRange(field,3,0,255) ) {
      alert(msg + showText(slan38));
      return false;
   }
   if ( !checkDigitRange(field,4,0,254) ) {
      alert(msg + showText(slan39));
      return false;
   }
   return true;
}

function checkSubnet(ip, mask, client)
{
  ip_d = getDigit(ip, 1);
  mask_d = getDigit(mask, 1);
  client_d = getDigit(client, 1);
  if ( (ip_d & mask_d) != (client_d & mask_d ) )
	return false;

  ip_d = getDigit(ip, 2);
  mask_d = getDigit(mask, 2);
  client_d = getDigit(client, 2);
  if ( (ip_d & mask_d) != (client_d & mask_d ) )
	return false;

  ip_d = getDigit(ip, 3);
  mask_d = getDigit(mask, 3);
  client_d = getDigit(client, 3);
  if ( (ip_d & mask_d) != (client_d & mask_d ) )
	return false;

  ip_d = getDigit(ip, 4);
  mask_d = getDigit(mask, 4);
  client_d = getDigit(client, 4);
  if ( (ip_d & mask_d) != (client_d & mask_d ) )
	return false;

  return true;
}

function subnetRule(ip, mask, client) {
	if (client!="0.0.0.0") {
        if ( !checkSubnet(ip, mask, client)) {
            alert(showText(slan33));
            //client.value = client.defaultValue;
						//client.focus();
            return false;
        }
    }
	return true;
}

function macRule( mac ) {
	var str = mac;
	if ( str.length < 12) {
		alert(showText(slan47));

		return false;
	}

	for (var i=0; i<str.length; i++) {
		if ( (str.charAt(i) >= '0' && str.charAt(i) <= '9') ||
			(str.charAt(i) >= 'a' && str.charAt(i) <= 'f') ||
			(str.charAt(i) >= 'A' && str.charAt(i) <= 'F') )
			continue;

		alert(showText(slan48));

		return false;
	}
		return true;
}

function setFocus(field) {
	field.focus();
	return;
}