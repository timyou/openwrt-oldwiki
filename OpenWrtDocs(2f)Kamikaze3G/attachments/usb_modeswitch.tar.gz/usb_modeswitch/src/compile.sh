#!/bin/sh
gcc -l usb -o usb_modeswitch usb_modeswitch.c
strip usb_modeswitch

