// StdAfx.h

#ifndef __STDAFX_H
#define __STDAFX_H

#include "../../../Common/MyWindows.h"

#endif
