// PPC.h

#ifndef __PPC_H
#define __PPC_H

#include "BranchCoder.h"

MyClassA(BC_PPC_B, 0x02, 5)

#endif
