// Pat2R.h

#ifndef __PAT2R__H
#define __PAT2R__H

#undef PAT_CLSID
#define PAT_CLSID CLSID_CMatchFinderPat2R

#undef PAT_NAMESPACE
#define PAT_NAMESPACE NPat2R

#define __NODE_2_BITS

#include "Pat.h"
#include "PatMain.h"

#undef  __NODE_2_BITS

#endif

